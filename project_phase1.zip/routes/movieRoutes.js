const express = require("express");
const router = express.Router();
const Movie = require('../models/movieModel');
// const { ObjectId } = require("bson");

router.get('/',async (req,res) => {
    try{
    await res.render('movies/index')
    }catch(error){
        res.send(error);
    }
})
// app.get('/update/movie', (req, res, next) =>{
//     res.render('movies/add')
// })
router.get('/add', async (req, res) => {
    try{
   await res.render("movies/add")
    }
    catch(error){
        res.send(error);
    }
  })

// gets all movies
// router.get('/api/Movies', async (req,res) => {
//     try{
//     const movies = await Movie.find()
//     res.send(movies);
//     }catch(error){
//         res.send("error")
//     }
// })

// gets movie by plot
router.get('/api/:id', async  (req,res) => {
    try{
    const movies = await Movie.findOne({plot: req.params.id})
   if(movies == ''){
    res.send("error")
   }res.send(movies)
//    res.render('movies/add')
}catch(error){
    res.send(error)
}
   
})



// get movie by _id
router.get('/searchById/:id', async (req,res) => {
    try{
    const movies = await Movie.findById(req.params.id)
    res.send(movies);
    }catch(error){
        res.send(error);
    }
});
// search
router.post("/api/getMovieId", async (req,res)=> {
    try{
        console.log(req.body.id);
        const txt = await Movie.findById(req.body.id);
        res.render('movies/list', {txt});

    }catch(error){
        res.send(error);
    }
})

// creates a movie
router.post('/api/Movies', async (req,res) => {
try{
    const movie = await Movie.create({
        plot: req.body.plot,
        runtime : req.body.runtime,
        title : req.body.title,
        released : req.body.released

    });
    res.render('movies/index',{successMessage: "Movie Added"});
}catch(error){
    res.send(error);
}
})


// update using the put method
router.put('/api/movies/:id', async (req,res) => {
    try{
        const movies = await Movie.findById(req.params.id);
        if(!movies){
            res.send("no movie found")
        }

        const movieUpdate = await Movie.findByIdAndUpdate(req.params.id, req.body , {new : true})
        res.send("updated")


    }catch(error){
        res.status(500).send({ error: "Internal Server Error" });
    }
})

// update using the post method
router.post('/update/search/:id',async(req,res) => {
    try{
        
        const movies = await Movie.findByIdAndUpdate(req.params.id);
        if(!movies){
            res.send("no movie found")
        }

        const movieUpdate = await Movie.findByIdAndUpdate(req.params.id, req.body , {new : true})
        res.send("updated")

    }catch(error){
        res.send(error);
    }
})




// delete
router.get('/delete', async (req,res) => {
    try{
   await res.render('movies/delete')
    }catch(error){
        res.send(error)
    }
})

router.post('/dele',async(req,res) => {
    try{
        const movies = await Movie.findOneAndDelete(req.body.id);
        res.render("movies/index",{successMessage:"Movie Deleted"})
    }
catch(error){
    res.send(error)
}
});

router.get('/list',(req,res) => {
    try{
        res.render('movies/list')
    }catch(error){
        res.send(error)
    }
    
})

router.get('/search',(req,res) => {
    try{
    res.render('movies/search')
    }catch(error){
        res.send(error)
    }
})

router.get('/update',(req,res) => {
    try{
    res.render('movies/update')
    }catch(error){
        res.send(error)
    }
})

router.all("*", async (req,res) =>{ 
    try{
    res.render('movies/index', {errorMessage: "Page not found"});
    }catch(error){
        res.send(error)
    }
 });


module.exports = router;